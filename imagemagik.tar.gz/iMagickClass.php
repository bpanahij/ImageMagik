<?php

class imageMagic
{
  protected $image;
  

}

?>