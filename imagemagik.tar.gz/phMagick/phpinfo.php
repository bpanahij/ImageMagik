<?php

phpinfo();
?>